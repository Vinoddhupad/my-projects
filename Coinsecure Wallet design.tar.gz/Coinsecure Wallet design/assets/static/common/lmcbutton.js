// LettersMarket Clipboard Button
// LMCButton
// http://www.lettersmarket.com

function isNotEmpty(str) {
 return !((str == undefined) || (str == ''));
}


function ShowLMCButton(cliptext, capt, js, furl)
{
 var params = 'txt=' + encodeURIComponent(cliptext); 
 if (!isNotEmpty(furl)) { furl = "/static/common/lmcbutton.swf"; }
 if (isNotEmpty(capt)) { params += '&capt=' + capt; }
 if (isNotEmpty(js)) { params += '&js=' + js; }
 
document.write('<object width="30" height="15">');
document.write(' <param name="movie" value="' + furl + '">');
document.write(' <PARAM NAME=FlashVars VALUE="' + params + '">');
document.write(' <embed src="' + furl + '" flashvars="' + params + '"  width="30" height="15"></embed>');
document.write('</object>');

//alert('file: ' + furl + ' Params: ' + params); // debug
}
function ShowLMCButtonAlt(cliptext, capt, js, furl)
{
 var params = 'txt=' + encodeURIComponent(cliptext); 
 if (!isNotEmpty(furl)) { furl = "/static/common/lmcbutton.swf"; }
 if (isNotEmpty(capt)) { params += '&capt=' + capt; }
 if (isNotEmpty(js)) { params += '&js=' + js; }
 
var flash_movie = '<object id="copy-btn" width="30" height="15">';
flash_movie += ' <param name="movie" value="' + furl + '">';
flash_movie +=' <PARAM NAME=FlashVars VALUE="' + params + '">';
flash_movie +=' <PARAM NAME=wmode VALUE="transparent"><param name="scale" value="exactfit" />';
flash_movie +=' <embed id="flash-copy-btn" src="' + furl + '" flashvars="' + params + '" scale="exactfit" WMODE="transparent" width="30" height="15"></embed>';
flash_movie +='</object>';

return flash_movie;
//alert('file: ' + furl + ' Params: ' + params); // debug
}
